#include<iostream>
#include<ctime>

using namespace std;

int main(){

    srand(time(0));
    int n;
    int ws;
    cout<<"Enter the number frames and ws: ";
    cin>>n>>ws;

    int sent = 1;
    bool ack[100] = {false};

    while(sent<= n){
        bool s[100] = {false};

        for(int i = sent; i<sent+ws && i<=n; i++){
            if(!ack[i]){
                 cout<<"Sender: sending frame: "<<i<<endl;
            }
        }

        // Reciever side
        for(int i = sent; i<sent+ws && i<=n; i++){
            if(!ack[i]){
                bool lost = (rand()%10 < 3);

                if(lost){
                    cout<<"Reciever : Cannot recieve frame "<<i<<endl;
                }
                else{
                    cout<<"Reciever: Recieved frame "<<i<<endl;
                    s[i] = true;
                }
            }
        }

        // Ack thing 

        for(int i = sent; i<sent+ws && i<=n; i++ ){
            if(s[i]){
                bool acklost = (rand()%10 < 2);
                if(acklost){
                    cout<<"Ack not recieved for the frame "<<i<<endl;
                }
                else{
                    cout<<"Ack recieved for the frame "<<i<<endl;
                    ack[i] = true;
                }
            }
        }

        while(sent<=n && ack[sent]){
            sent++;
        }
    }
}



